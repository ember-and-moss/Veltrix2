# VELTRIX — GitHub Pages Datentresor

## Dateien im Repository

- `index.html` — VELTRIX-Oberfläche mit Übersicht, Dateitresor und Privatsphäre
- `style.css` — Design und Layout
- `app.js` — Navigation sowie Datei-Verschlüsselung und -Entschlüsselung
- `veltrix-entschluessler.html` — eigenständiger Entschlüssler, auch herunterladbar über die Website

## Auf GitHub veröffentlichen

1. Öffne das Repository und wähle **Add file → Upload files**.
2. Lade die vier oben genannten Website-Dateien (`index.html`, `style.css`, `app.js`, `veltrix-entschluessler.html`) direkt ins Repository-Hauptverzeichnis. `README.md` kann ebenfalls hochgeladen werden.
3. Klicke auf **Commit changes**. GitHub Pages verwendet `index.html` aus dem konfigurierten Veröffentlichungsordner.
4. Öffne die Website über ihre `https://`-Adresse und lade sie mit `Strg+F5` neu.

## Dateiverschlüsselung

- Lokal im Browser; Dateiinhalt wird nicht an einen VELTRIX-Server gesendet.
- AES-256-GCM, PBKDF2-HMAC-SHA-256 mit 600.000 Iterationen, zufälliger Salt und IV.
- Neue Dateien verwenden `VELTRIX2`, bei dem auch die Metadaten authentifiziert werden.
- Der Entschlüssler unterstützt `VELTRIX1` (ältere Dateien ohne authentifizierten Header) und `VELTRIX2`.
- Maximal 100 MB pro Datei; beim Verschlüsseln mindestens 12 Zeichen Passwort.
- Verlorene Passwörter können nicht wiederhergestellt werden. Bewahre eine Originalkopie auf, bis eine Entschlüsselung mit dem richtigen Passwort erfolgreich getestet wurde.

Diese Software wurde nicht unabhängig sicherheitsauditiert. Verwende sie nicht als einzige Kopie für unersetzliche Dateien.
