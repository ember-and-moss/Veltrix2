'use strict';

// VELTRIX local file vault — hardened replacement for app.js
// Keeps compatibility with existing VELTRIX1 files; new files use authenticated VELTRIX2 headers.

const nav = [...document.querySelectorAll('.nav-item')];
const views = [...document.querySelectorAll('.view')];
const title = document.getElementById('pageTitle');
const titles = { home: 'Übersicht', vault: 'Dateitresor', privacy: 'Privatsphäre' };
function showView(name) {
  views.forEach(view => view.classList.toggle('active', view.id === `view-${name}`));
  nav.forEach(button => button.classList.toggle('active', button.dataset.view === name));
  if (title) title.textContent = titles[name] || titles.home;
}
nav.forEach(button => button.addEventListener('click', () => showView(button.dataset.view)));
document.querySelectorAll('[data-go]').forEach(button => button.addEventListener('click', () => showView(button.dataset.go)));

const encFile = document.getElementById('encryptFile');
const encPass = document.getElementById('encryptPassword');
const decFile = document.getElementById('decryptFile');
const decPass = document.getElementById('decryptPassword');
const er = document.getElementById('encryptResult');
const dr = document.getElementById('decryptResult');
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });
const MAX_FILE_BYTES = 100 * 1024 * 1024;
const MAX_CONTAINER_BYTES = MAX_FILE_BYTES + 16 * 1024;
const PBKDF2_ITERATIONS = 600000;
const FORMAT_V2 = 'VELTRIX2';
const FORMAT_V1 = 'VELTRIX1';

function message(element, text, success = false) {
  if (!element) return;
  element.textContent = text;
  element.style.color = success ? '#90d9cf' : '#efad9f';
}
function bytesToBase64(bytes) {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}
function base64ToBytes(value, expectedLength) {
  if (typeof value !== 'string' || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) {
    throw new Error('Ungültige Dateistruktur');
  }
  const binary = atob(value);
  const bytes = Uint8Array.from(binary, character => character.charCodeAt(0));
  if (expectedLength !== undefined && bytes.length !== expectedLength) throw new Error('Ungültige Dateistruktur');
  return bytes;
}
function safeFilename(value) {
  if (typeof value !== 'string') return 'datei';
  const name = value.replace(/[\\/\u0000-\u001f\u007f]/g, '_').trim().slice(0, 180);
  return (!name || name === '.' || name === '..') ? 'datei' : name;
}
function saveFile(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = safeFilename(filename);
  link.rel = 'noopener';
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function cryptoReady() {
  return Boolean(window.isSecureContext && window.crypto && window.crypto.subtle && window.crypto.getRandomValues);
}
function validateEncryptionPassword(password) {
  if (typeof password !== 'string' || password.length < 12) throw new Error('Bitte ein Passwort mit mindestens 12 Zeichen verwenden.');
  if (encoder.encode(password).length > 1024) throw new Error('Das Passwort ist zu lang.');
}
async function deriveKey(password, salt) {
  const material = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}
function parseContainer(bytes) {
  const newline = bytes.indexOf(10);
  if (newline < 2 || newline > 4096) throw new Error('Ungültiger Dateikopf');
  const headerBytes = bytes.slice(0, newline);
  const header = JSON.parse(decoder.decode(headerBytes));
  if (!header || typeof header !== 'object' || Array.isArray(header)) throw new Error('Ungültiger Dateikopf');
  if (header.format !== FORMAT_V1 && header.format !== FORMAT_V2) throw new Error('Unbekanntes Dateiformat');
  if (typeof header.name !== 'string' || header.name.length > 500) throw new Error('Ungültiger Dateiname');
  if (typeof header.type !== 'string' || header.type.length > 200) throw new Error('Ungültiger Dateityp');
  const salt = base64ToBytes(header.salt, 16);
  const iv = base64ToBytes(header.iv, 12);
  return { header, headerBytes, salt, iv, ciphertext: bytes.slice(newline + 1) };
}

if (!cryptoReady()) {
  message(er, 'Sichere Browser-Kryptografie nicht verfügbar. Öffne VELTRIX über HTTPS oder localhost.');
  message(dr, 'Sichere Browser-Kryptografie nicht verfügbar. Öffne VELTRIX über HTTPS oder localhost.');
}

document.getElementById('encryptBtn').addEventListener('click', async () => {
  const file = encFile?.files?.[0];
  const password = encPass?.value ?? '';
  if (!file) return message(er, 'Bitte eine Datei auswählen.');
  if (!cryptoReady()) return message(er, 'Bitte VELTRIX über HTTPS oder localhost öffnen.');
  try {
    validateEncryptionPassword(password);
    if (file.size > MAX_FILE_BYTES) throw new Error('Maximal 100 MB pro Datei.');
    message(er, 'Verschlüsselung läuft …');
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const header = {
      format: FORMAT_V2,
      name: safeFilename(file.name),
      type: (file.type || 'application/octet-stream').slice(0, 200),
      salt: bytesToBase64(salt),
      iv: bytesToBase64(iv)
    };
    const headerBytes = encoder.encode(JSON.stringify(header));
    const key = await deriveKey(password, salt);
    const plain = await file.arrayBuffer();
    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv, additionalData: headerBytes, tagLength: 128 },
      key,
      plain
    );
    saveFile(new Blob([headerBytes, new Uint8Array([10]), encrypted], { type: 'application/octet-stream' }), `${safeFilename(file.name)}.vltx`);
    encPass.value = '';
    message(er, 'Fertig. Verschlüsselte Kopie gespeichert.', true);
  } catch (error) {
    const known = error instanceof Error && /Passwort|100 MB|zu lang/.test(error.message);
    message(er, known ? error.message : 'Verschlüsselung fehlgeschlagen. Bitte mit einer Testdatei erneut versuchen.');
  }
});

document.getElementById('decryptBtn').addEventListener('click', async () => {
  const file = decFile?.files?.[0];
  const password = decPass?.value ?? '';
  if (!file) return message(dr, 'Bitte eine .vltx-Datei auswählen.');
  if (!cryptoReady()) return message(dr, 'Bitte VELTRIX über HTTPS oder localhost öffnen.');
  if (!password || encoder.encode(password).length > 1024) return message(dr, 'Bitte das passende Passwort eingeben.');
  try {
    if (file.size > MAX_CONTAINER_BYTES) throw new Error('Die Datei überschreitet die erlaubte Größe.');
    message(dr, 'Entschlüsselung läuft …');
    const bytes = new Uint8Array(await file.arrayBuffer());
    const { header, headerBytes, salt, iv, ciphertext } = parseContainer(bytes);
    if (ciphertext.length < 16 || ciphertext.length > MAX_FILE_BYTES + 16) throw new Error('Ungültige Dateigröße');
    const key = await deriveKey(password, salt);
    const algorithm = { name: 'AES-GCM', iv, tagLength: 128 };
    // VELTRIX2 authenticates the header metadata. VELTRIX1 remains supported for older files.
    if (header.format === FORMAT_V2) algorithm.additionalData = headerBytes;
    const plaintext = await crypto.subtle.decrypt(algorithm, key, ciphertext);
    saveFile(new Blob([plaintext], { type: header.type || 'application/octet-stream' }), safeFilename(header.name));
    decPass.value = '';
    message(dr, 'Fertig. Datei entschlüsselt und gespeichert.', true);
  } catch (error) {
    const known = error instanceof Error && /Größe/.test(error.message);
    message(dr, known ? error.message : 'Entschlüsselung fehlgeschlagen: Passwort falsch, Datei beschädigt oder Format ungültig.');
  }
});
